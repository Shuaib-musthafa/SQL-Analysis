CREATE DATABASE ecommerce_db;
USE ecommerce_db;

-- Customers table
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(255),
    country VARCHAR(100)
);

-- Orders table
CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    amount DECIMAL(10,2),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- Customers
INSERT INTO customers VALUES
(1, 'John Doe', 'USA'),
(2, 'Jane Smith', 'Canada'),
(3, 'Alex Johnson', 'UK');

-- Orders
INSERT INTO orders VALUES
(101, 1, '2024-01-10', 500.00),
(102, 1, '2024-02-15', 1500.00),
(103, 2, '2024-03-20', 700.00);

-- Find all orders greater than $500
SELECT * FROM orders WHERE amount > 500;

-- Join customers and orders
SELECT customers.customer_name, orders.amount
FROM customers
INNER JOIN orders ON customers.customer_id = orders.customer_id;


 -- Average order amount
SELECT AVG(amount) FROM orders;

-- Find customers who made orders above average
SELECT customer_id
FROM orders
WHERE amount > (SELECT AVG(amount) FROM orders);

-- View for high-value orders
CREATE VIEW high_value_orders AS
SELECT * FROM orders WHERE amount > 1000;

-- Optimize using index
CREATE INDEX idx_amount ON orders(amount);



